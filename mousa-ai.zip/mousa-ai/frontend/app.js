const chatEl = document.getElementById('chat');
const form = document.getElementById('chat-form');
const promptInp = document.getElementById('prompt');
const themeBtn = document.getElementById('toggle-theme');

// Theme toggle
function setTheme(t){
  if(t==='dark') document.documentElement.classList.add('dark');
  else document.documentElement.classList.remove('dark');
  localStorage.theme=t;
}
setTheme(localStorage.theme || 'light');
themeBtn.addEventListener('click', ()=>{
  const next = document.documentElement.classList.contains('dark') ? 'light' : 'dark';
  setTheme(next);
});

function addMessage(text, who='bot'){
  const div = document.createElement('div');
  div.className = 'msg ' + (who==='user' ? 'user' : 'bot');
  div.innerHTML = text;
  chatEl.appendChild(div);
  window.scrollTo(0, document.body.scrollHeight);
}

form.addEventListener('submit', async e=>{
  e.preventDefault();
  const prompt = promptInp.value.trim();
  if(!prompt) return;
  addMessage(escapeHtml(prompt), 'user');
  promptInp.value='';

  // placeholder loading
  const loading = document.createElement('div');
  loading.className='msg bot';
  loading.innerHTML = '<span class="loader"></span> ...';
  chatEl.appendChild(loading);
  window.scrollTo(0, document.body.scrollHeight);

  try{
    const res = await fetch('/api/chat', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({message: prompt})
    });
    const data = await res.json();
    loading.remove();
    if(data.error) addMessage('<b>خطأ:</b> '+escapeHtml(data.error), 'bot');
    else addMessage(escapeHtml(data.reply), 'bot');
  }catch(err){
    loading.remove();
    addMessage('<b>خطأ في الاتصال</b>', 'bot');
  }
});

function escapeHtml(s){ return s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;'); }